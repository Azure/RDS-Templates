# PowerShell imports
$pslocation = "C:\temp\RDSPowershellModules"
# Broker URL
$brokerurl = "https://rdbroker.wvd.microsoft.com"
# TSL
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
# import PS
cd $pslocation
import-module ".\Microsoft.RdInfra.RdPowershell.dll"
# Establish connection to the infra
Add-RdsAccount -DeploymentUrl $brokerurl
# Tenant WVDBootcamp and helper variables
########################################
# Tenant 
$aadid1 = "6265f4e8-c5f1-4ac2-b92e-f372e0e78405"
$aadidsub1 = "25e8c5f2-1e4e-4b1e-bbef-00d911724630"
$tenant = "MVPBootcamp"
$tenantf = "MVPBootcamp"
$tenantd = "MVPBootcamp tenant contact STGeorgi"
# AppGroups
$appgroup = "Desktop Application Group"  
$appgroup1 = "user036" # replace with your email
# HostPool
$pool = "MVPBootcamp"

# Confirm tenant
Get-RdsTenant -Name $tenant
# Confirm Host pool
Get-RdsHostPool $tenant -HostPoolName $pool
# Confirm Session hosts heart beat
Get-RdsSessionHost $tenant -HostPoolName $pool

# Publishing remote desktop 
Add-RdsAppGroupUser $tenant $pool $appproup -UserPrincipalName "user037@wvdcontoso.com"
# Cleanup
# Remove-RdsAppGroupUser $tenant $pool $appgroup -UserPrincipalName "user037@wvdcontoso.com

# Publishing remote app
# create an appgroup
New-RdsAppGroup $tenant $pool $appgroup1 -ResourceType RemoteApp
Add-RdsAppGroupUser $tenant $pool $appgroup1 -UserPrincipalName user077@wvdcontoso.com

$obj = Get-RdsStartMenuApp $tenant $pool $appgroup1 
$obj.appAlias

New-RdsRemoteApp $tenant $pool $appgroup1 -Name "MS Paint" -AppAlias paint
New-RdsRemoteApp $tenant $pool $appgroup1 -Name "WordPad" -AppAlias wordpad

New-RdsRemoteApp $tenant $pool $appgroup1 -Name Edge -FilePath shell:Appsfolder\Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge -IconPath C:\Windows\SystemApps\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge.exe

# clean up
Remove-RdsRemoteApp $tenant $pool $appgroup1 -Name "MS Paint"
Remove-RdsRemoteApp $tenant $pool $appgroup1 -Name "WordPad"
Remove-RdsRemoteApp $tenant $pool $appgroup1 -Name Edge

# troubleshotting
New-RdsRemoteApp $tenant $pool $appgroup -Name "Chrome" -AppAlias googlechrome

Get-RdsDiagnosticActivities -ActivityId 947980ff-ce2a-4c41-b9a0-82b2eee29ff4 #error 
Get-RdsDiagnosticActivities -ActivityId 947980ff-ce2a-4c41-b9a0-82b2eee29ff4 -TenantName $tenant
Get-RdsDiagnosticActivities -ActivityId 947980ff-ce2a-4c41-b9a0-82b2eee29ff4 -TenantName $tenant -Detailed
(Get-RdsDiagnosticActivities -ActivityId 947980ff-ce2a-4c41-b9a0-82b2eee29ff4 -TenantName $tenant -Detailed).errors