<#
.SYNOPSIS
    Goal of this PowerShell file is to demonstrate RDS PowerShell modules. Lines are to be executed one at a time.
.DESCRIPTION
    Import RDS PowerShell modules
    Conenct to WVD Infra
    Setup helper variables
    Assign user to a remote desktop
    Create a remote application group
        Publish applications in the remote application group
        Assign user to the remote application group
    Troubleshooting cmdlets 
.PARAMETER <Parameter_Name>
    alias as the $appgroup name
.INPUTS
  <Inputs if any, otherwise state None>
.OUTPUTS
  <Outputs if any, otherwise state None - example: Log file stored in C:\Windows\Temp\<name>.log>
.NOTES
  Version:        2.0
  Author:         Stefan Georgiev
  Creation Date:  January 2019
  Purpose/Change: MS Ready Verion
  
.EXAMPLE
  N/A
#>
####################################
# CONNECT TO WINDOWS VIRTUAL DESKTOP
####################################
# folder where the powershell modules were unzip and unblocked
$pslocation = "C:\temp\RDSPowershellModules"
# wvd production enviornment 
$brokerurl = "https://rdbroker.wvd.microsoft.com"
# fix for TSL
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# import PS
cd $pslocation
import-module ".\Microsoft.RdInfra.RdPowershell.dll"

Add-RdsAccount -DeploymentUrl $brokerurl
Set-RdsContext -TenantGroupName "WVDValidation"
####################################

############################
# SETTING UP HELPER VARIABLE
############################
# tenant name is provided by instructor
$tenant1 = "WVDBootcamp"
# host pool name
$pool = "demoHP"
# appgroups
$appgroup = "YourAlias"
$appgroup1 = "Desktop Application Group"
############################

#############################
# PUBLISHING A REMOTE DESKTOP
#############################
# no create for the app group
Add-RdsAppGroupUser -TenantName $tenant1 -HostPoolName $pool -Appgroup $appgroup1 -UserPrincipalName user200@wvdbootcamp.onmicrosoft.com

###########################
# PUBLISHING AN APPLICATION
###########################
New-RdsAppGroup -TenantName $tenant1 -HostPoolName $pool -Name $appgroup -ResourceType RemoteApp # create app group

Get-RdsStartMenuApp -TenantName $tenant1 -HostPoolName $pool -AppGroupName $appgroup # get available apps

New-RdsRemoteApp $tenant1 $pool $appgroup -Name "WordPad" -FilePath "C:\Program Files\Windows NT\Accessories\wordpad.exe" -IconPath "C:\Program Files\Windows NT\Accessories\wordpad.exe" -IconIndex 0 # via path

New-RdsRemoteApp $tenant1 $pool $appgroup -Name Edge -FilePath shell:Appsfolder\Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge -IconPath C:\Windows\SystemApps\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge.exe # modern app

New-RdsRemoteApp $tenant1 $pool $appgroup -Name "Visual Studio Code" -AppAlias visualstudiocode # publish apps via alias
New-RdsRemoteApp $tenant1 $pool $appgroup -Name "MS Word" -AppAlias word
New-RdsRemoteApp $tenant1 $pool $appgroup -Name "Excel" -AppAlias excel
New-RdsRemoteApp $tenant1 $pool $appgroup -Name "FireFox" -AppAlias firefox
New-RdsRemoteApp $tenant1 $pool $appgroup -Name "Chrome" -AppAlias googlechrome
New-RdsRemoteApp $tenant1 $pool $appgroup -Name "Notepad PlusPlus" -AppAlias notepad
New-RdsRemoteApp $tenant1 $pool $appgroup -Name "OneNote" -AppAlias onenote2016

Add-RdsAppGroupUser -TenantName $tenant1 -HostPoolName $pool -Appgroup $appgroup -UserPrincipalName user230@wvdbootcamp.onmicrosoft.com #grant user access

# POST 32 bit client install
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "WordPad" # remove app 

Remove-RdsAppGroupUser -TenantName $tenant1 -HostPoolName $pool -Appgroup $appgroup -UserPrincipalName user001@wvdbootcamp.onmicrosoft.com # clean up user 


##################################
# TROUBLESHOOTING USER CONNECTIONS
##################################
New-RdsRemoteApp $tenant1 $pool $appgroup -Name "WordPadBad" -FilePath "C:\Program Files\Windows NT\Accessories\wordpad..exe" -IconPath "C:\Program Files\Windows NT\Accessories\wordpad.exe" -IconIndex 0 # via path bad app

Get-RdsDiagnosticActivities -UserName "user230@WVDbootcamp.onmicrosoft.com" -TenantName $tenant1 -StartTime "2/13/2019 8:26:19" # user230

Get-RdsDiagnosticActivities -UserName "user230@WVDbootcamp.onmicrosoft.com" -TenantName $tenant1 -StartTime "2/13/2019 8:26:19" -Outcome Failure

(Get-RdsDiagnosticActivities -UserName "user001@WVDbootcamp.onmicrosoft.com" -TenantName $tenant1 -ActivityId "2bf946e2-70e4-4ac6-809f-1a955ca20000" -Detailed).Errors

# CLEAN UP
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "Visual Studio Code"
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "MS Word" 
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "WordPad"
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "Excel" 
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "FireFox" 
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "Chrome" 
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "Notepad PlusPlus" 
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "OneNote" 
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "WordPad" 
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name "WordPadBad" 
Remove-RdsRemoteApp $tenant1 $pool $appgroup -Name Edge
# clean up user
Remove-RdsAppGroupUser -TenantName $tenant1 -HostPoolName $pool -Appgroup $appgroup -UserPrincipalName user020@wvdbootcamp.onmicrosoft.com

