 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | taller-x64-1.0.0.1125.msi | Pass   | 17.23MB  | 66.55          | 9.14        | 0.48        | 56.89         | 0           | 
