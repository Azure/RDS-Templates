 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | tLoader.Installer-x64.msi | Pass   | 400KB    | 42.41          | 5.26        | 0.47        | 36.65         | 0           | 
