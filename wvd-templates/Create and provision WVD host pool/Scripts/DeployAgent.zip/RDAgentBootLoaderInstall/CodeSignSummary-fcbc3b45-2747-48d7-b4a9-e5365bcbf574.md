 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | tLoader.Installer-x64.msi | Pass   | 400KB    | 43.26          | 5.06        | 0.55        | 37.61         | 0           | 
