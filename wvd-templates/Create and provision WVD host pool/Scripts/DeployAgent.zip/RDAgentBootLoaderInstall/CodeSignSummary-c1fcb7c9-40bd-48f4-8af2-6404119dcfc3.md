 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | tLoader.Installer-x64.msi | Pass   | 364KB    | 42.72          | 1.64        | 0.73        | 40.31         | 0           | 
