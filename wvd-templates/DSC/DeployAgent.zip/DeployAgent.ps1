﻿<#
.SYNOPSIS
Deploys RD Infra agent into target VM

.DESCRIPTION
This script will get the registration token for the target pool name, copy the installer into target VM and execute the installer with the registration token and broker URI

If the pool name is not specified it will retreive first one (treat this as random) from the deployment.

.PARAMETER ComputerName
Required the FQDN or IP of target VM

.PARAMETER AgentInstallerFolder
Required path to MSI installer file

.PARAMETER AgentBootServiceInstallerFolder
Required path to MSI installer file

.PARAMETER Session
Optional Powershell session into target VM

.PARAMETER StartAgent
Start the agent service (RdInfraAgent) immediately

.EXAMPLE

.\DeployAgent.ps1 -AgentInstallerFolder '.\RDInfraAgentInstall\' -AgentBootServiceInstallerFolder '.\RDAgentBootLoaderInstall\'" 
#>
#Requires -Version 4.0

Param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentInstallerFolder,
    
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentBootServiceInstallerFolder,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$RegistrationToken,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [bool]$StartAgent,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$DSCFunctionsFilePath,

    [Parameter(mandatory = $false)]
    [switch]$EnableVerboseMsiLogging
)

# Dot sourcing Functions.ps1 file
. ($DSCFunctionsFilePath)

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Test-IsAdmin {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

function runMsiWithRetry
{
    param(
        [Parameter(mandatory = $true)]
        [string]$programDisplayName,

        [Parameter(mandatory = $true)]
        [String[]]$argumentList, #Must have at least 1 value

        [Parameter(mandatory = $true)]
        [string]$msiOutputLogPath,

        [Parameter(mandatory = $false)]
        [switch]$isUninstall,

        [Parameter(mandatory = $false)]
        [switch]$msiLogVerboseOutput
    )

    if($msiLogVerboseOutput) {
        $argumentList += "/l*vx $msiOutputLogPath" 
    }
    else {
        $argumentList += "/l* $msiOutputLogPath"
    }

    $retryTimeToSleepInSec = 30
    $retryCount = 0
    do 
    {
        $modeAndDisplayName = ($(if ($isUninstall) {"Uninstalling"} else {"Installing"}) + " $programDisplayName")

        if($retryCount -gt 0)
        {
            Write-Log -Message "Retrying $modeAndDisplayName in $retryTimeToSleepInSec seconds because it failed with Exit code=$sts This will be retry number $retryCount"
            Start-Sleep -Seconds $retryTimeToSleepInSec
        }

        Write-Log -Message ( "$modeAndDisplayName" + $(if ($msiLogVerboseOutput) {" with verbose msi logging"} else {""}))

        $processResult = Start-Process -FilePath "msiexec.exe" -ArgumentList $argumentList -Wait -Passthru
        $sts = $processResult.ExitCode

        $retryCount++
    } 
    while($sts -eq 1618 -and $retryCount -lt 20) # Error code 1618 is ERROR_INSTALL_ALREADY_RUNNING.

    if($sts -eq 1618)
    {
        Write-Log -Message "Stopping retries for $modeAndDisplayName. The last attempt failed with Exit code=$sts"
        if(-not $isUninstall) {
            throw "Stopping because $modeAndDisplayName finished with Exit code=$sts"
        }
    }
    else 
    {
        Write-Log -Message "$modeAndDisplayName finished with Exit code=$sts"
    }
} 

# Convert relative paths to absolute paths if needed
Write-Log -Message "Boot loader folder is $AgentBootServiceInstallerFolder"
$AgentBootServiceInstaller = (dir $AgentBootServiceInstallerFolder\ -Filter *.msi | Select-Object).FullName
if ((-not $AgentBootServiceInstaller) -or (-not (Test-Path $AgentBootServiceInstaller)))
{
    throw "RD Infra Agent Installer package is not found '$AgentBootServiceInstaller'"
}

# Convert relative paths to absolute paths if needed
Write-Log -Message "Agent folder is $AgentInstallerFolder"
$AgentInstaller = (dir $AgentInstallerFolder\ -Filter *.msi | Select-Object).FullName
if ((-not $AgentInstaller) -or (-not (Test-Path $AgentInstaller)))
{
    throw "RD Infra Agent Installer package is not found '$AgentInstaller'"
}

if (!$RegistrationToken)
{
    throw "No registration token specified"
}

runMsiWithRetry -programDisplayName "RDAgentBootLoader" -isUninstall -argumentList @("/x {A38EE409-424D-4A0D-B5B6-5D66F20F62A5}", "/quiet", "/qn", "/norestart", "/passive") -msiOutputLogPath "C:\Users\AgentBootLoaderUnInstall.txt" -msiLogVerboseOutput:$EnableVerboseMsiLogging

runMsiWithRetry -programDisplayName "RD Infra Agent" -isUninstall -argumentList @("/x {5389488F-551D-4965-9383-E91F27A9F217}", "/quiet", "/qn", "/norestart", "/passive") -msiOutputLogPath "C:\Users\AgentUninstall.txt" -msiLogVerboseOutput:$EnableVerboseMsiLogging

runMsiWithRetry -programDisplayName "RD Infra Agent DLL" -isUninstall -argumentList @("/x {CB1B8450-4A67-4628-93D3-907DE29BF78C}", "/quiet", "/qn", "/norestart", "/passive") -msiOutputLogPath "C:\Users\AgentUninstall.txt" -msiLogVerboseOutput:$EnableVerboseMsiLogging

Write-Log -Message "Installing RDAgent BootLoader on VM $AgentBootServiceInstaller"
runMsiWithRetry -programDisplayName "RDAgent BootLoader" -argumentList @("/i $AgentBootServiceInstaller", "/quiet", "/qn", "/norestart", "/passive") -msiOutputLogPath "C:\Users\AgentBootLoaderInstall.txt" -msiLogVerboseOutput:$EnableVerboseMsiLogging

Write-Log -Message "Installing RD Infra Agent on VM $AgentInstaller"
runMsiWithRetry -programDisplayName "RD Infra Agent" -argumentList @("/i $AgentInstaller", "/quiet", "/qn", "/norestart", "/passive", "REGISTRATIONTOKEN=$RegistrationToken") -msiOutputLogPath "C:\Users\AgentInstall.txt" -msiLogVerboseOutput:$EnableVerboseMsiLogging

if ($StartAgent)
{
    $bootloaderServiceName = "RDAgentBootLoader"
    $startBootloaderRetryCount=0
    while( -not (Get-Service $bootloaderServiceName -ErrorAction SilentlyContinue))
    {
        $retry = ($startBootloaderRetryCount -lt 6)
        Write-Log -Message $("Service $bootloaderServiceName was not found. " + $(if ($retry) {"Retrying again in 30 seconds, this will be retry $startBootloaderRetryCount"} else {"Retry limit exceeded"}) )
        
        if(-not $retry ) {
            break
        }
    
        $startBootloaderRetryCount++
        Start-Sleep -Seconds 30
    }

    Write-Log -Message "Starting service $bootloaderServiceName"
    Start-Service $bootloaderServiceName -ErrorAction Stop
}
