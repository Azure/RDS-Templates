 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | staller-x64-1.0.0.982.msi | Pass   | 16.88MB  | 63.84          | 4.96        | 0.54        | 58.3          | 0           | 
