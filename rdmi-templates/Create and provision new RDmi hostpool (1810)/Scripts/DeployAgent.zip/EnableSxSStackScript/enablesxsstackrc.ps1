<# 
.Synopsis
Powershell script that enables inbox SxSStack to be used for reverse connect (for versions starting from RS4)
.Description
Creates a new registry and copies the full content in registery RDP-Tcp.
On top the contents copied, two additional fields are created for the new registery.
Then create a listener for the new registry so that an Inbox SxS Stack can be used for ReverseConnect.
.Parameter SxSStackVersionName
Optional
The name of the new registery created.
If not used the scripts assigns a default value to this parameter.
.Example
User needs to run this script with admin privileges since we are editing and creating the registery values.
.\enablesxsstackrc.ps1
#>

#This parameter will be taken as commandline parameter.
Param(
    [string]$SxSStackVersionName
)

#Checking the OSVersion number extracted from version string to determine whether the current OS is before or after RS4.
$RS4Version = "10.0.17083"
if([System.Environment]::OSVersion.VersionString.Split(" ")[[System.Environment]::OSVersion.VersionString.Split(" ").Length-1] -lt $RS4Version){
    Write-Error "Please use the MSI for the current OS version."
    throw
}

#Helper function to recursively traverse and add folders existing under RDP-Tcp
function addChildFolder($children, $destination){
    foreach($child in $children){
        $names = $child.Name.Split('\')
        if(-not ($names.Count -gt 0)){
            Write-Error "Child Name format is invalid"
            throw
        }
        $newDestination = $destination+ '\' + $names[$names.Count-1] 
        
        New-Item -ItemType Directory -Force -Path $newDestination

        $message = "Created directory for "+$names[$names.Count-1]
        Write-Output $message

        $existingFolder = $child.Name -replace "HKEY_LOCAL_MACHINE", "HKLM:"

        $childRegistry = Get-ItemProperty -Path $existingFolder
        $childProperties = $childRegistry.psobject.properties
        
        foreach($property in $childProperties){
            Copy-ItemProperty -Path $existingFolder -Destination $newDestination -Name $property.Name
        }

        $message = "Copied properties from "+$names[$names.Count-1]
        Write-Output $message

        $subChildren = Get-ChildItem -Path $existingFolder
        addChildFolder ($subChildren) ($newDestination)
    }
}

if([string]::IsNullOrEmpty($SxSStackVersionName)){
    $SxSStackVersionName = "rdp-sxs"
}

#This is used for errors that should be ignored.
$ErrorActionPreference = "SilentlyContinue"

$destinationRegistry = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\"+$SxSStackVersionName

if(Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"){
    
    #Create the new registery if it doesn't exist
    #If it exist then we will prompt user to uninstall the existing sxsstack for the given version.
    if(!(Test-Path $destinationRegistry)){
        New-Item -ItemType Directory -Force -Path $destinationRegistry
    
        $registryKey = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
        $propertiesToBeCopied = $registryKey.psobject.properties

        #Assign all existing properties of RDP-Tcp to the new Registery except fEnableWinStation
        foreach ($property in $propertiesToBeCopied) {
            if($property.Name -ne "fEnableWinStation"){
                Copy-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Destination $destinationRegistry -Name $property.Name
            }
            else{
                New-ItemProperty -Path $destinationRegistry -Name "fEnableWinStation" -Value 0
            }
        }

        $message = "Properties of RDP-Tcp are added to registery "+ $SxSStackVersionName
        Write-Output $message

        $rdpReverseConnectListener = "RDPRECCONNamedPipeServer_" + $SxSStackVersionName
        #Setting the extra properties neeeded
        New-ItemProperty -Path $destinationRegistry -Name "SxSStackType" -Value 3
        New-ItemProperty -Path $destinationRegistry -Name "ReverseConnectionPipeName" -Value $rdpReverseConnectListener

        $message = "Additional required key value pairs are added to "+ $SxSStackVersionName
        Write-Output $message

        $childFolders = Get-ChildItem -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
        addChildFolder ($childFolders) ($destinationRegistry)

        $message = "Child folders of RDP-Tcp are added to "+ $SxSStackVersionName
        Write-Output $message

        #Setting a listener on 1 level up.
        New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations" -Name "ReverseConnectionListener" -Value $SxSStackVersionName
        
        $message = "Reverse connect listener for "+ $SxSStackVersionName+ " is added to WinStations"
        Write-Output $message


        #Change the parameter on fEnableWinStation to 1.
        Set-ItemProperty -Path $destinationRegistry -Name "fEnableWinStation" -Value 1

        $message = "Enabled WinStation for " + $SxSStackVersionName
        Write-Output $message

        # this needs to be done after the stack is activated
        Write-Output "Setting active listener for RedirectionInfo"
        New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\ClusterSettings" -Name "SessionDirectoryListener" -Value $SxSStackVersionName

        $qwinstaOutput = & "qwinsta" | Out-String
        Write-Output $qwinstaOutput
    }
    else{
        $qwinstaOutput = & "qwinsta" | Out-String
        Write-Output $qwinstaOutput
        $errorMessage = "The SxSStack you wish to enable "+ $SxSStackVersionName + " already exists either specify a new name with parameter -SxSStackVersionName or disable the existing version.An example with a parameter would be: .\enablesxsstackrc -SxSStackVersionName 'sxsrcstack'"
        Write-Error $errorMessage
    }
}
else{
    $qwinstaOutput = & "qwinsta" | Out-String
    Write-Output $qwinstaOutput
    $errorMessage = "Inbox SxSStack is not installed so cannot generate new SxSStackVersion please check your settings."
    Write-Error $errorMessage
}

# SIG # Begin signature block
# MIIoFQYJKoZIhvcNAQcCoIIoBjCCKAICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAzLRJFViRO0Ydt
# Q8uQa/rRMgiVoDMp/mB7By9pY46jU6CCEWUwggh3MIIHX6ADAgECAhM2AAAAgrsy
# RpV6geNbAAEAAACCMA0GCSqGSIb3DQEBCwUAMEExEzARBgoJkiaJk/IsZAEZFgNH
# QkwxEzARBgoJkiaJk/IsZAEZFgNBTUUxFTATBgNVBAMTDEFNRSBDUyBDQSAwMTAe
# Fw0xODA3MTAxMzAyMzlaFw0xOTA3MTAxMzAyMzlaMCQxIjAgBgNVBAMTGU1pY3Jv
# c29mdCBBenVyZSBDb2RlIFNpZ24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQC6B/SG/b3ES+fa/jW7OzSAQxWlD1iY2W9U8MBJPBf23WR6PepYXO61z3JE
# H1MiAeAI8CA9XQCgUcrCXqQWJc6qEoSa2bScGXkApC7HukqFA+9cSdNe04QaS+S0
# RjWToYR09NjCCps6FLlmkwXZWgryrCGsAk48MggRMRNE2um1fSeEOWCLMHsFgWYN
# jwDxDsLpYhufbvvzwRBVy866Exm//HiOpR/vy1CEGZ37jT4LCklGIbvWJ7LuQ9Wj
# wZxj4JNwsx/AKwsDWweQ85Rfi+g3+FM7MCEyoJ98qEVTDApOZvUQEBxd771b97dR
# 5aKAfzc1H9oFDoh52jNmz3rDeWH/AgMBAAGjggWDMIIFfzApBgkrBgEEAYI3FQoE
# HDAaMAwGCisGAQQBgjdbAQEwCgYIKwYBBQUHAwMwPQYJKwYBBAGCNxUHBDAwLgYm
# KwYBBAGCNxUIhpDjDYTVtHiE8Ys+hZvdFs6dEoFgg93NZoaUjDICAWQCAQswggJ2
# BggrBgEFBQcBAQSCAmgwggJkMGIGCCsGAQUFBzAChlZodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpaW5mcmEvQ2VydHMvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDEpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDEu
# YW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUy
# MDAxKDEpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDIuYW1lLmdibC9haWEv
# QlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDEpLmNydDBS
# BggrBgEFBQcwAoZGaHR0cDovL2NybDMuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAx
# LkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDEpLmNydDBSBggrBgEFBQcwAoZG
# aHR0cDovL2NybDQuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDEpLmNydDCBrQYIKwYBBQUHMAKGgaBsZGFwOi8vL0NO
# PUFNRSUyMENTJTIwQ0ElMjAwMSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2Vy
# dmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1BTUUsREM9R0JM
# P2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9uQXV0
# aG9yaXR5MB0GA1UdDgQWBBSOTzmrWuq9s4lp8xOp1ano/K6DwDAOBgNVHQ8BAf8E
# BAMCB4AwUAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRp
# b25zIFB1ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzYxNjcrNDM4MDQyMIIB1AYDVR0f
# BIIByzCCAccwggHDoIIBv6CCAbuGPGh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2lpbmZyYS9DUkwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIYuaHR0cDovL2NybDEu
# YW1lLmdibC9jcmwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIYuaHR0cDovL2NybDIu
# YW1lLmdibC9jcmwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIYuaHR0cDovL2NybDMu
# YW1lLmdibC9jcmwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIYuaHR0cDovL2NybDQu
# YW1lLmdibC9jcmwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIaBumxkYXA6Ly8vQ049
# QU1FJTIwQ1MlMjBDQSUyMDAxLENOPUJZMlBLSUNTQ0EwMSxDTj1DRFAsQ049UHVi
# bGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlv
# bixEQz1BTUUsREM9R0JMP2NlcnRpZmljYXRlUmV2b2NhdGlvbkxpc3Q/YmFzZT9v
# YmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludDAfBgNVHSMEGDAWgBQbZqIZ
# /JvrpdqEjxiY6RCkw3uSvTAfBgNVHSUEGDAWBgorBgEEAYI3WwEBBggrBgEFBQcD
# AzANBgkqhkiG9w0BAQsFAAOCAQEAkTjDgWcKF5AekFyhXDv4trHLi7qyl4UZrgpC
# mKDeftiGYPzlwtxKNBKToum6mWxLS5QvkurudtJBR26IPRXOCjwr8G4CpcC+4DOY
# cTm6xTaWUsJwINkhOFG0OozHXcfaAsdHXnm27Bi9cDcbBu+BTGQYYUfwpONZNoOt
# CZNzahokKX5DRPlevedCKMOlmcF9s28dFsD4He+4cn3fFzC9DcaNn0IwKAMOZl2B
# 5KpANKBRiAxfLOXunlBuJayl/3k5r78bxefxxrDq1rO0gGla1c8sVceaYLl5lB7N
# VgwLLWgLI1lkk2axdHo3W4D2TJBU+RG2PSmmPMzsILYs8oTcYTCCCOYwggbOoAMC
# AQICEx8AAAAUtMUfxvKAvnEAAAAAABQwDQYJKoZIhvcNAQELBQAwPDETMBEGCgmS
# JomT8ixkARkWA0dCTDETMBEGCgmSJomT8ixkARkWA0FNRTEQMA4GA1UEAxMHYW1l
# cm9vdDAeFw0xNjA5MTUyMTMzMDNaFw0yMTA5MTUyMTQzMDNaMEExEzARBgoJkiaJ
# k/IsZAEZFgNHQkwxEzARBgoJkiaJk/IsZAEZFgNBTUUxFTATBgNVBAMTDEFNRSBD
# UyBDQSAwMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANVXgQLW+frQ
# 9xuAud03zSTcZmH84YlyrSkM0hsbmr+utG00tVRHgw40pxYbJp5W+hpDwnmJgicF
# oGRrPt6FifMmnd//1aD/fW1xvGs80yZk9jxTNcisVF1CYIuyPctwuJZfwE3wcGxh
# kVw/tj3ZHZVacSls3jRD1cGwrcVo1IR6+hHMvUejtt4/tv0UmUoH82HLQ8w1oTX9
# D7xj35Zt9T0pOPqM3Gt9+/zs7tPp2gyoOYv8xR4X0iWZKuXTzxugvMA63YsB4ehu
# SBqzHdkF55rxH47aT6hPhvDHlm7M2lsZcRI0CUAujwcJ/vELeFapXNGpt2d3wcPJ
# M0bpzrPDJ/8CAwEAAaOCBNowggTWMBAGCSsGAQQBgjcVAQQDAgEBMCMGCSsGAQQB
# gjcVAgQWBBSR/DPOQp72k+bifVTXCBi7uNdxZTAdBgNVHQ4EFgQUG2aiGfyb66Xa
# hI8YmOkQpMN7kr0wggEEBgNVHSUEgfwwgfkGBysGAQUCAwUGCCsGAQUFBwMBBggr
# BgEFBQcDAgYKKwYBBAGCNxQCAQYJKwYBBAGCNxUGBgorBgEEAYI3CgMMBgkrBgEE
# AYI3FQYGCCsGAQUFBwMJBggrBgEFBQgCAgYKKwYBBAGCN0ABAQYLKwYBBAGCNwoD
# BAEGCisGAQQBgjcKAwQGCSsGAQQBgjcVBQYKKwYBBAGCNxQCAgYKKwYBBAGCNxQC
# AwYIKwYBBQUHAwMGCisGAQQBgjdbAQEGCisGAQQBgjdbAgEGCisGAQQBgjdbAwEG
# CisGAQQBgjdbBQEGCisGAQQBgjdbBAEGCisGAQQBgjdbBAIwGQYJKwYBBAGCNxQC
# BAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMBIGA1UdEwEB/wQIMAYBAf8CAQAw
# HwYDVR0jBBgwFoAUKV5RXmSuNLnrrJwNp4x1AdEJCygwggFoBgNVHR8EggFfMIIB
# WzCCAVegggFToIIBT4YjaHR0cDovL2NybDEuYW1lLmdibC9jcmwvYW1lcm9vdC5j
# cmyGMWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2lpbmZyYS9jcmwvYW1lcm9v
# dC5jcmyGI2h0dHA6Ly9jcmwyLmFtZS5nYmwvY3JsL2FtZXJvb3QuY3JshiNodHRw
# Oi8vY3JsMy5hbWUuZ2JsL2NybC9hbWVyb290LmNybIaBqmxkYXA6Ly8vQ049YW1l
# cm9vdCxDTj1BTUVST09ULENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNl
# cyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPUFNRSxEQz1HQkw/Y2Vy
# dGlmaWNhdGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENsYXNzPWNSTERpc3Ry
# aWJ1dGlvblBvaW50MIIBqwYIKwYBBQUHAQEEggGdMIIBmTA3BggrBgEFBQcwAoYr
# aHR0cDovL2NybDEuYW1lLmdibC9haWEvQU1FUk9PVF9hbWVyb290LmNydDBHBggr
# BgEFBQcwAoY7aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraWluZnJhL2NlcnRz
# L0FNRVJPT1RfYW1lcm9vdC5jcnQwNwYIKwYBBQUHMAKGK2h0dHA6Ly9jcmwyLmFt
# ZS5nYmwvYWlhL0FNRVJPT1RfYW1lcm9vdC5jcnQwNwYIKwYBBQUHMAKGK2h0dHA6
# Ly9jcmwzLmFtZS5nYmwvYWlhL0FNRVJPT1RfYW1lcm9vdC5jcnQwgaIGCCsGAQUF
# BzAChoGVbGRhcDovLy9DTj1hbWVyb290LENOPUFJQSxDTj1QdWJsaWMlMjBLZXkl
# MjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPUFNRSxE
# Qz1HQkw/Y0FDZXJ0aWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNlcnRpZmljYXRp
# b25BdXRob3JpdHkwDQYJKoZIhvcNAQELBQADggIBACi3Soaajx+kAWjNwgDqkIvK
# AOFkHmS1t0DlzZlpu1ANNfA0BGtck6hEG7g+TpUdVrvxdvPQ5lzU3bGTOBkyhGmX
# oSIlWjKC7xCbbuYegk8n1qj3rTcjiakdbBqqHdF8J+fxv83E2EsZ+StzfCnZXA62
# QCMn6t8mhCWBxpwPXif39Ua32yYHqP0QISAnLTjjcH6bAV3IIk7k5pQ/5NA6qIL8
# yYD6vRjpCMl/3cZOyJD81/5+POLNMx0eCClOfFNxtaD0kJmeThwL4B2hAEpHTeRN
# tB8ib+cze3bvkGNPHyPlSHIuqWoC31x2Gk192SfzFDPV1PqFOcuKjC8049SSBtC1
# X7hyvMqAe4dop8k3u25+odhvDcWdNmimdMWvp/yZ6FyjbGlTxtUqE7iLTLF1eaUL
# SEobAap16hY2N2yTJTISKHzHI4rjsEQlvqa2fj6GLxNj/jC+4LNy+uRmfQXShd30
# lt075qTroz0Nt680pXvVhsRSdNnzW2hfQu2xuOLg8zKGVOD/rr0GgeyhODjKgL2G
# Hxctbb9XaVSDf6ocdB//aDYjiabmWd/WYmy7fQ127KuasMh5nSV2orMcAed8CbIV
# I3NYu+sahT1DRm/BGUN2hSpdsPQeO73wYvp1N7DdLaZyz7XsOCx1quCwQ+bojWVQ
# TmKLGegSoUpZNfmP9MtSMYIWBjCCFgICAQEwWDBBMRMwEQYKCZImiZPyLGQBGRYD
# R0JMMRMwEQYKCZImiZPyLGQBGRYDQU1FMRUwEwYDVQQDEwxBTUUgQ1MgQ0EgMDEC
# EzYAAACCuzJGlXqB41sAAQAAAIIwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcN
# AQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUw
# LwYJKoZIhvcNAQkEMSIEILyl3qmjHcErwEKz4ejRE+hxukI37sDj4idJ/tMvnWsu
# MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEAUQOZ2GIwLCp2
# W0i7nF8OGwGBr97CSMCJYchKkh1OVsRgklh1pJNxfIAAvzcl32JTDrTv4JnJ0buS
# NYHwiQ36c/SFffFqcWJj1t0LHU4BxO0nOzS0xJG/mLEQC0gfaqXURzcXHrRSnJgf
# v8x0Mdv3tpvVB6lpqJtC9y0GJxqvUHjzoKr4sKbzMbCkjscziAVqYNwIvB4LBjWx
# rl1VO/GAPy/VHGjRGFueyGW171QRt01kVmhYOn8o9LfMH8GIDllkMZhfNkANpmoI
# 9m+DKuCVGRZzbiEU8+zLXcMJxmiHLq1WEAbOKfJYbN61RvzrUMj4tmdZ8MwJhQvl
# BAOiLljWL6GCE84wghPKBgorBgEEAYI3AwMBMYITujCCE7YGCSqGSIb3DQEHAqCC
# E6cwghOjAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFYBgsqhkiG9w0BCRABBKCCAUcE
# ggFDMIIBPwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUABCD1QqX6knwc
# BQ5iDxaaypdqUiOH0ABaDFHJ/A7QKDy7+AIGW60D8ZTwGBMyMDE4MTAwMTIxNDA1
# MS43MzdaMAcCAQGAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVy
# dG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046OThGRC1DNjFFLUU2NDEx
# JTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wggg8eMIIE9TCC
# A92gAwIBAgITMwAAAMtfeMsjDpSXwwAAAAAAyzANBgkqhkiG9w0BAQsFADB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMyMDI2MjRaFw0xOTEx
# MjMyMDI2MjRaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8gUmljbzEmMCQG
# A1UECxMdVGhhbGVzIFRTUyBFU046OThGRC1DNjFFLUU2NDExJTAjBgNVBAMTHE1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDFeMgd7/AdQXAcbTRKP1QCyhp4swNVghCFNtgwqcsvN/DtFZVu
# w9ylKJmTyFN57MdzMWkF6WotDolbPgz7h6naCrbLmAmjMXgx4aHQoD1nT0/TTdIZ
# 4JwtO0dpwwdjYb7UQaa+Fd+u/dT6otwrLCg3S4wazkFIahJ/EtFT+cZXQ0D3zCKa
# kRUHT+lLeHb2iPzL2uXvOh22sCcXRiq03R6eyzmnt2B19uZIW4bjWraqd3Q7tw6O
# sQxNQSGthrlBmWuKB1TcFiFpN0meMWZWq093gIu9dslsnk64xr+ekco3vMg4gbXf
# tVAp+u7dE8EKU2vmtmTz9r/B8kMUHoHPvU4VAgMBAAGjggEbMIIBFzAdBgNVHQ4E
# FgQUKOTy5vbJ0U2ubsjbKpa/McP72XYwHwYDVR0jBBgwFoAU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQu
# Y29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3Js
# MFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcnQwDAYD
# VR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQsFAAOC
# AQEAi/RhhYMFYmzLFJSXw+klA2xysS/aTemWDIPmjkxPAMgofaA+h3Lop1I5I+mn
# 0FOt074FUVhMWCS860AcrAIdhoGxpCiD7XVeskEDJScXJV6UePLdY0tVbwV9CpLE
# eQav+P9HufPo171GlNiXFEFcN5R5/SP2LUCXrgL5zXyxDcSShNwOxTozgMPnxB+P
# ThitSAUfcoV0vq+h7JRbhS34yuw1PPfgrtcwIPSUwgq6pVksnVgKQGIfwAiJzjSx
# x6fTmXYpQuNsxowfEaP9O2KjAIz4Su2XtdpVk4YmSBanOX2U8Qoty9k/KUCPdfzc
# buAp6SMy11MEl1MZCKX0jbCuzjCCBnEwggRZoAMCAQICCmEJgSoAAAAAAAIwDQYJ
# KoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0
# eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVowfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEssX8XD5WHCdrc+
# Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgIs0Ldk6zWczBX
# JoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHEpl3RYRNuKMYa
# +YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1AUdEPnAY+Z3/1
# ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTznL0S6p/TcZL2k
# AcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkrBgEEAYI3FQEE
# AwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJKwYBBAGCNxQC
# BAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYD
# VR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJB
# dXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJKwYBBAGCNy4D
# MIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vUEtJL2Rv
# Y3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABf
# AFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEB
# CwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn++ldtGTCzwsVm
# yWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBBm9xcF/9c+V4X
# NZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmptWvkx872ynoA
# b0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rbV0Dp8c6ZZpCM
# /2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5Hfw42JT0xqUK
# loakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoGig+JFrphpxHL
# mtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEHpJM692VHeOj4
# qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpUObJb2sgNVZl6
# h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlBTeCG+SqaoxFm
# MNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4wwP3M5k37Db9d
# T+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJEqGCA6wwggKU
# AgEBMIH+oYHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8gUmljbzEm
# MCQGA1UECxMdVGhhbGVzIFRTUyBFU046OThGRC1DNjFFLUU2NDExJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJBgUrDgMCGgUAAxUA
# uaOT0kB20bcfFaMEUZeuOCvbmiGggd4wgdukgdgwgdUxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRp
# b25zIFB1ZXJ0byBSaWNvMScwJQYDVQQLEx5uQ2lwaGVyIE5UUyBFU046NERFOS0w
# QzVFLTNFMDkxKzApBgNVBAMTIk1pY3Jvc29mdCBUaW1lIFNvdXJjZSBNYXN0ZXIg
# Q2xvY2swDQYJKoZIhvcNAQEFBQACBQDfXNA8MCIYDzIwMTgxMDAyMDA1NjI4WhgP
# MjAxODEwMDMwMDU2MjhaMHMwOQYKKwYBBAGEWQoEATErMCkwCgIFAN9c0DwCAQAw
# BgIBAAIBFjAHAgEAAgIbpzAKAgUA314hvAIBADA2BgorBgEEAYRZCgQCMSgwJjAM
# BgorBgEEAYRZCgMBoAowCAIBAAIDFuNgoQowCAIBAAIDB6EgMA0GCSqGSIb3DQEB
# BQUAA4IBAQBCfmgtvGlgXJiTFbeaFcnUdbE983BDDdnbWjHwroStazdSxohLtNt7
# D53yJwIJqt4LEpA1+74XqTeYE8pR1c7DRs/EEZ+5erOMazK7MnJt+6dfz2vXeu3W
# uwpwvjEP/Y3GkdBM7EubpLfL3KGj1dQ1a6dVP/i6mD7vuHj7PyAyQC/AxQ5LJYKZ
# BHshXBELTiDLKyGRj3WKrKKSsnxQhARn6/w2cvkmgvi84XsAAGjWBsn2wpsBz3Fm
# hPEI5QFCls3J3bSlf18nPKIT5/Mlk9h4rnxWmFu0AC8VehhTbZH5brrd0D1G4eHE
# g8RskgZ0m4cbGTgNrvil2+jE5wIj1vtnMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAADLX3jLIw6Ul8MAAAAAAMswDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQg6bjSfBQ0BD2NtORt6HCj5cAvXaUjzafVnr7i7BAuxi4wgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCA2JyGqqWCnXutz0KS9S3wuF/afS9Mu7hRH
# Xqpg3cEdZDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAAAy194yyMOlJfDAAAAAADLMCIEIK8N+LW0DtBNgbPnEb+cqzRGLkeQ0Oyj7Xpm
# R9xFzpH1MA0GCSqGSIb3DQEBCwUABIIBADHX8Q2FVgaje8PPOK3trGYAE1zCSTy0
# WplIe0lN8JOIBP8FsAgyZY+TDeuCZqOT0hax0fb+IkltB1xq45xStTMwQLYD/OMS
# l14VFCpTuNvbwxPFW+zgPt2ZPnrJQHjFr+znflvp9wmk1fq942Xj20h7qbEGmziB
# iu5KNdQKhhXuhk738Rx8ma8L8yGIO7tXpG11Ix7wXDA1uceeSxnz0HDvLlHxETj5
# 9rZZpCp2nJLoy1ouuBu+x7Gk+ER2K2nyYe+bMMzqV+h1+qxWSEefraPhsFvGiB8t
# ahqqgmsRxoD5uLdOy57oakMK4xEYUMQbyMughBAJYAoTtUNndwHiyjM=
# SIG # End signature block
