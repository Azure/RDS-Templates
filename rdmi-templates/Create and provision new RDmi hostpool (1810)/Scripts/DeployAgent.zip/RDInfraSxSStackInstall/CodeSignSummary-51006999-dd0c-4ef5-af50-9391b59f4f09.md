 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | tackSxS.Installer-x64.msi | Pass   | 27.02MB  | 45.63          | 4.23        | 0.57        | 40.8          | 0           | 
